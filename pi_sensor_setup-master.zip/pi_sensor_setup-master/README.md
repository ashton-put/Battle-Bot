# Raspberry Pi - Sensors Interfacing

This repository contains code required to get meaningful data from (integrate the sensor with raspberry pi):
1. Ultrasonic Sensor
2. IMU
3. This repository contains instrutions to run motors via Motor controller module.
4. This repository also includes a directory containing code for a web based video streaming from the camera module of raspberry pi.
